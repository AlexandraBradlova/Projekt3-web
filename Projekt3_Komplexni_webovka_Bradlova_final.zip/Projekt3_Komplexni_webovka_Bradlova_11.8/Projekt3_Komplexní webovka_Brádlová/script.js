// --------------------- MENU BAR SECTION ---------------------

const menuIcon = document.querySelector (".menu-icon")
const menuList = document.querySelector ("nav")
const hamburgerIcon = document.querySelector (".fa-solid")


menuIcon.addEventListener ("click",() => {
    if (hamburgerIcon.classList[1]  === "fa-bars-staggered") {
        hamburgerIcon.classList.add("fa-xmark")
        hamburgerIcon.classList.remove("fa-bars-staggered")
        menuList.style.display = "block"
        darkModeButton.style.display = "none"

    } else {
        hamburgerIcon.classList.add ("fa-bars-staggered")
        hamburgerIcon.classList.remove ("fa-xmark")
        menuList.style.display = "none"
        darkModeButton.style.display = ""


    }        
   
})

// ------------------- SCROLL BUTTON PART --------------------

// nahrání položek z HTML souboru
const scrollDiv = document.querySelector(".scroll");
const scrollBtn = document.getElementById("scroll-top-Btn");

// při kliknutí mě to hodí nahoru
scrollBtn.addEventListener("click", () => {
  window.scrollTo(0, 0);
});

// show/hide button on scroll
// musí byt navazano na celé window!!!
window.addEventListener("scroll", () => {
  // console.log(window.Math.round(scrollY));
  if (scrollY >= 600) {
    scrollDiv.style.display = "block";
  } else {
    scrollDiv.style.display = "none";
  }
});

// ------------- LIGHT/DARK MODE BUTTON --------------------------------

const body = document.querySelector ("body")
const darkModeButton = document.getElementById ("button-dark-mode")

  // toggle mezi tridami light mode a dakr mode

darkModeButton.addEventListener ("click", ()=>{
  document.body.classList.toggle ("turn-dark")


})



// ---------------- PASSWORD CHECKER --------------------------------------

// logika - obecne pouzitelny kod
class twoContentChecker {
  constructor(twoHTMLtags) {
      this.twoHTMLtags = twoHTMLtags  }

  getInputContent = (input) => {
      return input.value
  }
  insertContent = (htmlTag, content) => {
      htmlTag.textContent = content
  }
  addClass = (htmltag, className) => {
      htmltag.classList.add(className)
  }
  removeClass = (htmltag, className) => {
      htmltag.classList.remove(className)
  }
  // - vymazání textu v odstavci "shodne/neshodne" kdyz neni nic vyplnene
  htmlTagCleaner = (input1value, input2value, htmlTag) => {
      if (input1value == "" && input2value == "") {
          htmlTag.textContent = ""
      }
  }
}
//  Použití v praxi
const passwordInputs = document.querySelectorAll(".password-input")
const paragraphText = document.querySelector(".result-text")

const inputChecker = new twoContentChecker(passwordInputs)

inputChecker.twoHTMLtags.forEach( (oneInput) => {
  oneInput.addEventListener("input", () => {
      const password1Value = inputChecker.getInputContent(inputChecker.twoHTMLtags[0])
      const password2Value = inputChecker.getInputContent(inputChecker.twoHTMLtags[1])

  if (password1Value == password2Value) {
      inputChecker.insertContent(paragraphText, "Hesla jsou shodná, pokračujte") 
      inputChecker.addClass(paragraphText, "valid")                   
      inputChecker.removeClass(paragraphText, "invalid")              
  } else {
      inputChecker.insertContent(paragraphText, "Hesla nejsou stejná")   
      inputChecker.addClass(paragraphText, "invalid")                     
      inputChecker.removeClass(paragraphText, "valid")                    
  }

      inputChecker.htmlTagCleaner(password1Value, password2Value, paragraphText)
  })
})